$(document).ready(function(){
    $(".hamburger").on("click",function(){
        $(".main").toggleClass("collapse");
    });
})
